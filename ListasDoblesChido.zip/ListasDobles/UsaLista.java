public class UsaLista{
    public static void main(String[] args){
        ListaDoble lista = new ListaDoble();

        lista.insertaPrimerNodo("H");
        lista.insertaAntesPrimerNodo("O");
        lista.insertaAlFinal("Y");
        lista.insertaEntreNodos("R", "A");

        System.out.println("Lista original:");
        lista.imprimir();
        System.out.println();

        //Buscar un nodo por su clave y imprimir su referencia
        String valorBuscado = "H";
        Nodo nodoBuscado = lista.buscarPorClave(valorBuscado);
        if(nodoBuscado != null){
            System.out.println("Nodo [ " + valorBuscado + " ] encontrado con valor: " + nodoBuscado);
        }else{
            System.out.println("Nodo no encontrado");
        }

        //Insertar un nuevo nodo después de un nodo con un valor específico
        lista.insertarDespues("Y", "Z");
        System.out.println("\nInserta Nodo [ Z ] después del Nodo [ Y ]:");
        lista.imprimir();

        //Intercambiar nodos
        lista.intercambiarNodo("H", "Z");
        System.out.println("\nIntercambiar Nodo [ H ] por [ Z ]:");
        lista.imprimir();
    }
}
