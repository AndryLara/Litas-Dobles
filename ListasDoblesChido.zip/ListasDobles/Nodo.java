//clase autorreferenciada
public class Nodo{
    String name; //campo de datos
    Nodo previous; //campo enlace
    Nodo next;   //campo enlace
}