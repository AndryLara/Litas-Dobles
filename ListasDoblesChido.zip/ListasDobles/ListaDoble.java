public class ListaDoble{

    Nodo topForward;
    Nodo topBackward;

    //Método para insertar el primer nodo en la lista
    public boolean insertaPrimerNodo(String dato){
        if(topForward == null){
            //creamos el primer nodo
            topForward = new Nodo();
            topForward.name = dato;
            topForward.previous = null;
            topForward.next = null;

            topBackward = topForward;

            return true;
        }else{
            //lista ya tiene elementos
            return false;
        }
    }

    // Método para imprimir la lista
    public void imprimir(){
        System.out.print("[X]");

        for(Nodo temp = this.topForward; temp != null; temp = temp.next){
            System.out.print(" <- [ " + temp.name + " ] -> ");
        }

        System.out.print("[X]\n");
    }

    //Método para convertir la lista a una cadena de texto
    public String toString(){
        StringBuilder cadAux = new StringBuilder("[X]");
        for(Nodo temp = this.topForward; temp != null; temp = temp.next){
            cadAux.append(" <- [ ").append(temp.name).append(" ] -> ");
        }

        cadAux.append("[X]\n");

        return cadAux.toString();
    }

    //Método para insertar un nodo antes del primer nodo
    public void insertaAntesPrimerNodo(String nombre){
        Nodo temp = new Nodo();
        temp.name = nombre;
        temp.next = this.topForward;
        this.topForward.previous = temp;
        this.topForward = temp;
    }

    //Método para insertar un nodo al final de la lista
    public void insertaAlFinal(String nombre){
        Nodo temp = new Nodo();
        temp.name = nombre;
        temp.next = null;

        temp.previous = this.topBackward;
        this.topBackward.next = temp;
        this.topBackward = temp;
    }

    //Método para insertar un nodo entre dos nodos existentes
    public boolean insertaEntreNodos(String nombre, String buscado){
        Nodo temp = new Nodo();
        temp.name = nombre;
        Nodo temp2 = this.topForward;

        while((temp2 != null) && !temp2.name.equals(buscado)){
            temp2 = temp2.next;
        }

        if(temp2 != null){
            temp.next = temp2.next;
            temp2.next = temp;

            temp.previous = temp2;
            temp.next.previous = temp;

            return true;
        }else{
            return false;
        }
    }

    //Método para borrar el primer nodo de la lista
    public void borrarPrimerNodo(){
        this.topForward = this.topForward.next;
        this.topForward.previous.next = null;
        this.topForward.previous = null;
    }

    //Método para borrar el último nodo de la lista
    public void borrarUltimoNodo(){
        this.topBackward = this.topBackward.previous;
        this.topBackward.next.previous = null;
        this.topBackward.next = null;
    }

    //Método para borrar cualquier nodo que no sea el primero
    public boolean borrarCualquierNodo(String buscado){
        Nodo temp = this.topForward;

        while((temp != null) && !temp.name.equals(buscado)){
            temp = temp.next;
        }

        if(temp != null){
            temp.next = temp.next.next;
            temp.next.previous.previous = null;
            temp.next.previous.next = null;
            temp.next.previous = temp;

            return true;
        }else{
            return false;
        }
    }

    //Método para buscar un nodo por su clave y devolver una referencia
    public Nodo buscarPorClave(String clave){
        Nodo temp = this.topForward;

        while(temp != null){
            if(temp.name.equals(clave)){
                return temp;
            }
            temp = temp.next;
        }

        return null; // No se encontró el nodo
    }

    //Método para buscar un nodo por su clave e insertar un nuevo nodo después de él
    public boolean insertarDespues(String clave, String nombre){
        Nodo nodoBuscado = buscarPorClave(clave);

        if(nodoBuscado != null){
            if(nodoBuscado.next == null){
                // El nodo buscado es el último de la lista
                insertaAlFinal(nombre);
            }else{
                // El nodo buscado no es el último de la lista
                Nodo nuevoNodo = new Nodo();
                nuevoNodo.name = nombre;
                nuevoNodo.next = nodoBuscado.next;
                nodoBuscado.next = nuevoNodo;

                nuevoNodo.previous = nodoBuscado;
                nuevoNodo.next.previous = nuevoNodo;
            }
            return true;
        }

        return false; // No se encontró el nodo
    }
    
    //Método para intercambiar un nodo por otro buscado
    public boolean intercambiarNodo(String nombre, String buscado){
        //Buscar los nodos a intercambiar
        Nodo nodo1 = buscarPorClave(nombre);
        Nodo nodo2 = buscarPorClave(buscado);

        //Verificar si ambos nodos fueron encontrados
        if(nodo1 != null && nodo2 != null){
            //Intercambiar los nodos en la lista
            Nodo tempPrev1 = nodo1.previous;
            Nodo tempNext1 = nodo1.next;
            Nodo tempPrev2 = nodo2.previous;
            Nodo tempNext2 = nodo2.next;

            //Actualiza punteros de nodo1
            nodo1.previous = tempPrev2;
            nodo1.next = tempNext2;

            //Actualiza punteros de nodo2
            nodo2.previous = tempPrev1;
            nodo2.next = tempNext1;

            //Actualizar punteros de nodos previos
            if(tempPrev1 != null){
                tempPrev1.next = nodo2;
            }
            if(tempPrev2 != null){
                tempPrev2.next = nodo1;
            }

            //Actualizar punteros de nodos siguientes
            if (tempNext1 != null){
                tempNext1.previous = nodo2;
            }
            if(tempNext2 != null){
                tempNext2.previous = nodo1;
            }

            return true;
        }

        return false; // No se encontraron los nodos o alguno de ellos no fue encontrado
    }
}
